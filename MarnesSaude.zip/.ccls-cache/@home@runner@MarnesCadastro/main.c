
#include <stdio.h>
#include <string.h> 
int main(void) {
  char opcao,sexo;
  char user[100], senha[100], testeU[100], testeS[100];
    float peso, alt, imc, tmb;
    int idade, obj, disponibilidade, alt2, sug, dieta;

  do {
  printf("Bem-vindo!\n a)Fazer cadastro \n b)Entrar\n c)Sair\n");
  scanf(" %c", &opcao);
    if (opcao == 'a' || opcao == 'A') {
      printf("Nome de usúario: ");
      scanf("%s", user);
      printf("Senha: ");
      scanf("%s", senha);
      printf("qual seu sexo, masculino ou feminino?\n F) Feminino\n M) Masculino\n");
      scanf( " %c", &sexo);
      
      printf("Qual a sua idade?\n");
      scanf("%d", &idade);
      printf("\n");
      printf("*****************************\n");
      printf("Cadastro realizado com sucesso!\n");
      printf("*****************************\n");
    }
  if (opcao == 'b' || opcao == 'B') {
    printf("Nome de usúario: ");
    scanf("%s", testeU);
    printf("Senha: ");
    scanf("%s", testeS);
    printf("\n");
    if (strcmp(testeU, user) == 0 && strcmp(testeS, senha) == 0) {
      printf("******************************************\n");
      printf("Bem-vindo, %s\n", user);
      printf("******************************************\n");
      break;
    } else{
      printf("Nome de usúario ou senha incorretos, voltando ao menu...\n");
      printf("*****************************************\n");
      printf("\n");
      }
    }
  }while (opcao != 'c' && opcao != 'C');
  
  printf("\n");
  printf("digite o seu peso: ");
  scanf("%f", &peso);
  printf("digite a altura: ");
  scanf("%f", &alt);
  imc = peso / (alt * alt);
  if(imc < 18.5){
    printf("abaixo do peso\n");
    printf("*****************************************\n");
  }else if(imc > 18.5 && imc < 24.99){
    printf("peso normal\n");
    printf("*****************************************\n");
  }else if(imc > 25 && imc < 29.99){
    printf("excesso de peso\n");
    printf("*****************************************\n");
  }else if(imc > 30 && imc < 34.99){
    printf("obesidade classe 1\n");
    printf("*****************************************\n");
  }else if(imc > 35 && imc < 39.99){
    printf("obesidade classe 2\n");
    printf("*****************************************\n");
  }else if(imc >= 40){
    printf("obesidade classe 3\n");
    printf("*****************************************\n");
  }else{
    printf("erro");
}

  printf("Vamos calcular a quantidade de calorias que você deve consumir por dia para manter seu peso.\n");
  printf("\n");
  printf("Escreva a sua altura em cm: ");
  scanf("%i", &alt2);
  if (sexo == 'f' || sexo == 'F'){
    tmb = 447.593 + (9.247 * peso) + (3.098 * alt) - (4.330 * idade);
  }
  else if (sexo == 'm' || sexo == 'M'){
    tmb = 88.362 + (13.397 * peso) + (4.799 * alt) - (5.677 * idade);
  }
  printf("A quantidade de calorias que você deve consumir por dia para manter seu peso é: %.2f\n", tmb);
  printf("*****************************************\n");
  
  printf("\n");
  
  printf("\nqual seu objetivo?\n1 - perder-peso\n2 - ganhar massa\n");
   scanf("%d", &obj);

  printf("Entre 3 e 5,quantos dias voce tem disponiveis para praticar exercícios físicos?\n");
  scanf("%d", &disponibilidade);

 
  
    if ((sexo == 'f' || sexo == 'F') && (obj == 1) && (disponibilidade == 3)){

      printf("Nossa recomendação é um treino ABC, \nDia A: Treino de membros inferiores\n pernas e glúteos\n"
         "Agachamento com barra: 3 séries de 10-12 repetições\n"
         "Afundo com halteres: 3 séries de 10-12 repetições cada perna\n"
         "Levantamento terra: 3 séries de 10-12 repetições\n"
         "Cadeira extensora: 3 séries de 12-15 repetições\n"
         "Glúteos na máquina: 3 séries de 12-15 repetições\n"
         "Dia B: Treino de membros superiores (costas, peito, ombros, braços)\n"
         "Supino reto com halteres: 3 séries de 10-12 repetições\n"
         "Remada com barra: 3 séries de 10-12 repetições\n"
         "Desenvolvimento militar com halteres: 3 séries de 10-12 repetições\n"
         "Rosca direta com barra: 3 séries de 12-15 repetições\n"
         "Tríceps pulley corda: 3 séries de 12-15 repetições\n"
         "Dia C: Treino de corpo inteiro (exercícios compostos e cardio)\n"
         "Corrida ou caminhada rápida: 20-30 minutos\n"
         "Flexões: 3 séries de 10-15 repetições\n"
         "Agachamento com salto: 3 séries de 10-12 repetições\n"
         "Prancha: 3 séries de 30-60 segundos\n"
         "Abdominais: 3 séries de 15-20 repetições");
    }
    else if ((sexo == 'f' || sexo == 'F') && (obj == 1) && (disponibilidade == 4)){
      printf("Nossa recomendação é um treino ABCD\n"
         "Segunda-feira (Treino A - Parte Superior do Corpo)\n"
         "Supino Inclinado com Halteres: 3 sets de 10-12 repetições\n"
         "Elevação Lateral: 3 sets de 12-15 repetições\n"
         "Remada Curvada: 3 sets de 10-12 repetições\n"
         "Rosca Direta: 3 sets de 10-12 repetições\n"
         "Prancha: 3 sets de 30-60 segundos\n"
      
         "Terça-feira (Treino B - Parte Inferior do Corpo e Cardio)\n"
         "Agachamento: 4 sets de 10-12 repetições\n"
         "Afundo com Barra: 3 sets de 10 repetições cada perna\n"
         "Glúteos na Máquina: 3 sets de 12-15 repetições\n"
         "Cardio: 20-30 minutos de corrida moderada ou elíptico\n"
        
         "Quinta-feira (Treino C - Parte Superior do Corpo)\n"
        
         "Flexão de Braços: 3 sets de 10-15 repetições\n"
         "Pull-ups assistidos ou Remada Alta: 3 sets de 10-12 repetições\n"
         "Tríceps Pulley: 3 sets de 12-15 repetições\n"
         "Rosca Martelo: 3 sets de 10-12 repetições\n"
         "Prancha Lateral: 3 sets de 30 segundos cada lado\n"
        "Sexta-feira Treino D - Parte Inferior do Corpo e Cardio\n"
        "Levantamento Terra: 4 sets de 8-10 repetições\n"
        "Cadeira Extensora: 3 sets de 10-12 repetições\n"
        "Elevação de Panturrilha: 3 sets de 15-20 repetições\n"
        "Cardio: 20-30 minutos de bicicleta estacionária ou corrida leve");
    }
    else if ((sexo == 'f' || sexo == 'F') && (obj == 1) && (disponibilidade == 5)){
      printf("Segunda-feira (Treino A - Parte Superior do Corpo):\n"
         "Flexões: 3 sets de 10-15 repetições\n"
         "Remada com halteres: 3 sets de 10-12 repetições\n"
         "Elevação lateral com halteres: 3 sets de 12-15 repetições\n"
         "Rosca direta com halteres: 3 sets de 10-12 repetições\n"
         "Tríceps francês com halteres (deitada): 3 sets de 10-12 repetições\n"
         "Terça-feira (Treino B - Cardio):\n"
         "30 minutos de corrida, bicicleta estacionária, elíptico ou outra atividade cardiovascular de sua escolha.\n"
         "Quarta-feira (Treino C - Pernas e Abdômen):\n"
         "Agachamento corporal: 3 sets de 12-15 repetições\n"
         "Afundo: 3 sets de 10-12 repetições para cada perna\n"
         "Elevação pélvica (ponte de quadril): 3 sets de 12-15 repetições\n"
         "Prancha: 3 sets de 30-60 segundos\n"
         "Crunches: 3 sets de 15-20 repetições\n"
         "Quinta-feira (Treino D - Cardio e Alongamento):\n"
         "30 minutos de cardio moderado (corrida, bicicleta, natação, etc.)\n"
         "10-15 minutos de alongamento para todos os principais grupos musculares\n"
         "Sexta-feira (Treino E - Treino em Circuito):\n"
         "Realize os seguintes exercícios em um circuito, descansando 30 segundos entre cada exercício e 2 minutos entre cada circuito:\n"
         "Flexões: 12 repetições\n"
         "Agachamento corporal: 15 repetições\n"
         "Prancha: 30 segundos\n"
         "Elevação lateral com halteres: 12 repetições\n"
         "Repita o circuito 3-4 vezes.\n");

    }


      
    else if ((sexo == 'f' || sexo == 'F') && (obj == 2) && (disponibilidade == 3)){
      printf("Nossa recomendação é um treino ABC\n"
         "Dia A: Treino de membros inferiores (pernas e glúteos)\n"
         "Agachamento com barra: 4 séries de 8-10 repetições\n"
         "Leg press: 4 séries de 8-10 repetições\n"
         "Cadeira extensora: 3 séries de 10-12 repetições\n"
         "Cadeira flexora: 3 séries de 10-12 repetições\n"
         "Elevação pélvica (com peso): 3 séries de 12-15 repetições\n"
         "Dia B: Treino de membros superiores (costas, peito, ombros, braços)\n"
         "Supino reto com barra: 4 séries de 8-10 repetições\n"
         "Puxada na máquina (ou remada curvada): 4 séries de 8-10 repetições\n"
         "Desenvolvimento com halteres: 3 séries de 8-10 repetições\n"
         "Rosca direta com barra: 3 séries de 10-12 repetições\n"
         "Tríceps pulley corda: 3 séries de 10-12 repetições\n"
         "Dia C: Treino de corpo inteiro (exercícios compostos e isolados)\n"
         "Levantamento terra: 4 séries de 8-10 repetições\n"
         "Flexões (com peso, se possível): 4 séries de 8-10 repetições\n"
         "Agachamento frontal com barra: 3 séries de 8-10 repetições\n"
         "Remada cavalinho (T-bar): 3 séries de 10-12 repetições\n"
         "Elevação lateral (com halteres): 3 séries de 10-12 repetições\n");
    }
      
    else if ((sexo == 'f' || sexo == 'F') && (obj == 2) && (disponibilidade == 4)){
      printf("Nossa recomendação é um treino ABC\n"
        "Segunda-feira (Treino A - Parte Superior do Corpo:\n"
         "Supino Reto com Barra: 4 sets de 8-10 repetições\n"
         "Puxada de Lat Barra Fixa: 4 sets de 8-10 repetições\n"
         "Desenvolvimento com Halteres: 3 sets de 8-10 repetições\n"
         "Rosca Alternada com Halteres: 3 sets de 8-10 repetições\n"
        "Tríceps Corda no Pulley: 3 sets de 10-12repetições\n"
         "Terça-feira (Treino B - Parte Inferior do Corpo:\n"
         "Agachamento Livre: 4 sets de 8-10 repetições\n"
         "Cadeira Flexora: 4 sets de 8-10 repetições\n"
         "Cárdio: 20 minutos de aquecimento na esteira\n"
         "Afundo com Barra: 3 sets de 10 repetições cada perna\n"
         "Elevação de Panturrilha Sentada: 3 sets de 12-15 repetições\n"
         "Quinta-feira Treino C - Parte Superior do Corpo:\n"
         "Supino Declinado com Halteres: 4 sets de 8-10 repetições\n"
         "Remada Unilateral com Halteres: 4 sets de 8-10 repetições\n"
         "Elevação Frontal com Halteres: 3 sets de 8-10 repetições\n"
         "Tríceps Francês: 3 sets de 10-12 repetições\n"
         "Rosca Scott: 3 sets de 8-10 repetições\n"
         "Sexta-feira (Treino D - Parte Inferior do Corpo):\n"
         "Levantamento Terra: 4 sets de 6-8 repetições\n"
         "Leg Press 45°: 4 sets de 8-10 repetições\n"
         "Extensão de Quadril na Máquina: 3 sets de 10-12 repetições\n"
         "Flexão Plantar Sentada: 3 sets de 12-15 repetições\n");

    }
    else if ((sexo == 'f' || sexo == 'F') && (obj == 2) && (disponibilidade == 5)){
      printf("Nossa recomendação é um treino ABCDE \n"
        "Segunda-feira Treino A - Membros Inferiores\n"
         "Agachamento Livre: 4 sets de 8-10 repetições\n"
         "Leg Press: 3 sets de 10-12 repetições\n"
         "Cadeira Extensora: 3 sets de 10-12 repetições\n"
         "Elevação de Panturrilha em Pé: 4 sets de 12-15 repetições\n"
         "Terça-feira (Treino B - Membros Superiores)\n"
         "Supino Inclinado com Barra: 4 sets de 8-10 repetições\n"
         "Remada Curvada: 3 sets de 10-12 repetições\n"
         "Desenvolvimento com Halteres: 3 sets de 10-12 repetições\n"
         "Rosca Direta: 3 sets de 10-12 repetições\n"
         "Tríceps Pulley: 3 sets de 10-12 repetições\n"
         "Quarta-feira (Descanso/Recuperação)\n"
         "Quinta-feira (Treino C - Membros Inferiores)\n"
         "Levantamento Terra: 4 sets de 6-8 repetições\n"
         "Agachamento Hack: 3 sets de 8-10 repetições\n"
         "Mesa Flexora: 3 sets de 10-12 repetições\n"
         "Elevação de Panturrilha Sentada: 4 sets de 12-15 repetições\n"
         "Sexta-feira (Treino D - Membros Superiores)\n"
         "Supino Reto com Barra: 4 sets de 8-10 repetições\n"
         "Barra Fixa ou Puxada na Máquina: 3 sets de 8-10 repetições\n"
         "Desenvolvimento Militar com Barra: 3 sets de 10-12 repetições\n"
         "Rosca Alternada com Halteres: 3 sets de 10-12 repetições\n"
         "Tríceps Corda no Pulley: 3 sets de 10-12 repetições\n"
         "Sábado (Treino E - Corpo Completo e Cardio)\n"
         "Corrida ou Elíptico: 20-30 minutos\n"
         "Flexões: 3 sets até a falha muscular\n"
         "Pull-ups Assistidos ou Pulldowns: 3 sets de 8-10 repetições\n"
         "Lunges com Halteres: 3 sets de 10-12 repetições cada perna\n"
         "Prancha: 3 sets de 30-60 segundos");
  }
   else if ((sexo == 'm' || sexo == 'M') && (obj == 1) && (disponibilidade == 3)){

     printf("Segunda-feira (Treino A - Parte Superior do Corpo):\n"
        "• Supino: 3 sets de 10-12 repetições\n"
        "• Pull-ups (ou puxadas na barra fixa): 3 sets de 8-10 repetições (ou use uma banda de resistência para assistência)\n"
        "• Desenvolvimento militar: 3 sets de 10-12 repetições\n"
        "• Remada curvada: 3 sets de 10-12 repetições\n"
        "• Flexões: 3 sets até a falha muscular\n\n"
        "Quarta-feira (Treino B - Inferior do Corpo e Core):\n"
        "• Agachamento: 3 sets de 10-12 repetições\n"
        "• Levantamento terra (ou deadlift): 3 sets de 8-10 repetições\n"
        "• Lunges: 3 sets de 10 repetições para cada perna\n"
        "• Prancha: 3 sets de 30-60 segundos\n"
        "• Abdominais (escolha um exercício de abdominais que você goste, como crunches ou sit-ups): 3 sets de 15-20 repetições\n\n"
        "Sexta-feira (Treino C - Parte Superior do Corpo e Cardio):\n"
        "• Supino inclinado com halteres: 3 sets de 10-12 repetições\n"
        "• Rosca direta com barra: 3 sets de 10-12 repetições\n"
        "Elevação lateral: 3 sets de 12-15 repetições\n"
        "Tríceps coice: 3 sets de 10-12 repetições\n"
        "Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha\n");
     
   }
  else if ((sexo == 'm' || sexo == 'M') && (obj == 1) && (disponibilidade == 4)){

    printf("Segunda-feira (Treino A - Parte Superior do Corpo e Cardio):\n"
       "• Supino: 3 sets de 10-12 repetições\n"
       "• Barra fixa (ou pull-ups): 3 sets de 8-10 repetições (ou use uma banda de resistência para assistência)\n"
       "• Desenvolvimento militar: 3 sets de 10-12 repetições\n"
       "• Remada curvada: 3 sets de 10-12 repetições\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n\n"
       "Terça-feira (Treino B - Inferior do Corpo e Core):\n"
       "• Agachamento: 3 sets de 10-12 repetições\n"
       "• Levantamento terra (ou deadlift): 3 sets de 8-10 repetições\n"
       "• Lunges: 3 sets de 10 repetições para cada perna\n"
       "• Prancha: 3 sets de 30-60 segundos\n"
       "• Abdominais (escolha um exercício de abdominais que você goste, como crunches ou sit-ups): 3 sets de 15-20 repetições\n\n"
       "Quinta-feira (Treino C - Parte Superior do Corpo e Cardio):\n"
       "• Supino inclinado com halteres: 3 sets de 10-12 repetições\n"
       "• Rosca direta com barra: 3 sets de 10-12 repetições\n"
       "• Elevação lateral: 3 sets de 12-15 repetições\n"
       "• Tríceps coice: 3 sets de 10-12 repetições\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n\n"
       "Sexta-feira (Treino D - Treino em Circuito e Cardio):\n"
       "• Realize os seguintes exercícios em um circuito, descansando 30 segundos entre cada exercício e 2 minutos entre cada circuito:\n"
       "  1. Flexões: 15 repetições\n"
       "  2. Agachamentos: 15 repetições\n"
       "  3. Pull-ups (ou puxadas na barra fixa assistidas por banda de resistência): 10 repetições\n"
       "  4. Prancha: 30 segundos\n"
       "• Repita o circuito 3-4 vezes.\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n");
    
   }
  else if ((sexo == 'm' || sexo == 'M') && (obj == 1) && (disponibilidade == 5)){

    printf("Segunda-feira (Treino A - Parte Superior do Corpo e Cardio):\n"
       "• Supino: 3 sets de 10-12 repetições\n"
       "• Barra fixa (ou pull-ups): 3 sets de 8-10 repetições (ou use uma banda de resistência para assistência)\n"
       "• Desenvolvimento militar: 3 sets de 10-12 repetições\n"
       "• Remada curvada: 3 sets de 10-12 repetições\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n\n"
       "Terça-feira (Treino B - Inferior do Corpo e Core):\n"
       "• Agachamento: 3 sets de 10-12 repetições\n"
       "• Levantamento terra (ou deadlift): 3 sets de 8-10 repetições\n"
       "• Lunges: 3 sets de 10 repetições para cada perna\n"
       "• Prancha: 3 sets de 30-60 segundos\n"
       "• Abdominais (escolha um exercício de abdominais que você goste, como crunches ou sit-ups): 3 sets de 15-20 repetições\n\n"
       "Quarta-feira (Treino C - Cardio e Flexibilidade):\n"
       "• Cardio: 30-40 minutos de corrida, ciclismo, natação, pular corda, ou outra atividade cardiovascular de sua escolha.\n"
       "• Alongamento: Dedique 10-15 minutos para alongar todos os principais grupos musculares.\n\n"
       "Quinta-feira (Treino D - Parte Superior do Corpo e Cardio):\n"
       "• Supino inclinado com halteres: 3 sets de 10-12 repetições\n"
       "• Rosca direta com barra: 3 sets de 10-12 repetições\n"
       "• Elevação lateral: 3 sets de 12-15 repetições\n"
       "• Tríceps coice: 3 sets de 10-12 repetições\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n\n"
       "Sexta-feira (Treino E - Treino em Circuito e Cardio):\n"
       "• Realize os seguintes exercícios em um circuito, descansando 30 segundos entre cada exercício e 2 minutos entre cada circuito:\n"
       "  1. Flexões: 15 repetições\n"
       "  2. Agachamentos: 15 repetições\n"
       "  3. Pull-ups (ou puxadas na barra fixa assistidas por banda de resistência): 10 repetições\n"
       "  4. Prancha: 30 segundos\n"
       "• Repita o circuito 3-4 vezes.\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n");
  
   }
  else if ((sexo == 'm' || sexo == 'M') && (obj == 2) && (disponibilidade == 3)){

    printf("Segunda-feira (Treino A - Peito, Ombros e Tríceps):\n"
       "• Supino reto: 4 sets de 8-12 repetições\n"
       "• Supino inclinado com halteres: 3 sets de 8-12 repetições\n"
       "• Desenvolvimento militar: 4 sets de 8-12 repetições\n"
       "• Elevação lateral: 3 sets de 10-15 repetições\n"
       "• Extensão de tríceps com halteres: 3 sets de 10-12 repetições\n"
       "• Tríceps na polia alta: 3 sets de 10-12 repetições\n\n"
       "Quarta-feira (Treino B - Costas e Bíceps):\n"
       "• Puxada na frente (Pull-ups): 4 sets de 8-12 repetições\n"
       "• Remada com barra: 4 sets de 8-12 repetições\n"
       "• Remada unilateral com halteres: 3 sets de 10-12 repetições\n"
       "• Rosca direta com barra: 3 sets de 10-12 repetições\n"
       "• Rosca martelo: 3 sets de 10-12 repetições\n\n"
       "Sexta-feira (Treino C - Pernas e Abdômen):\n"
       "• Agachamento livre: 4 sets de 8-12 repetições\n"
       "• Leg press: 3 sets de 10-12 repetições\n"
       "• Cadeira extensora: 3 sets de 10-12 repetições\n"
       "• Flexão plantar em pé: 4 sets de 10-15 repetições\n"
       "• Prancha: 3 sets de 30-60 segundos\n"
       "• Crunches: 3 sets de 15-20 repetições\n");
    
   }
  else if ((sexo == 'm' || sexo == 'M') && (obj == 2) && (disponibilidade == 4)){

     printf("Segunda-feira (Treino A - Peito e Tríceps):\n"
        "• Supino reto: 4 sets de 8-12 repetições\n"
        "• Supino inclinado com halteres: 4 sets de 8-12 repetições\n"
        "• Crucifixo inclinado: 3 sets de 10-15 repetições\n"
        "• Paralelas: 3 sets até a falha muscular\n"
        "• Extensão de tríceps com corda (na polia alta): 3 sets de 10-12 repetições\n"
        "• Tríceps francês (deitado): 3 sets de 10-12 repetições\n\n"
        "Terça-feira (Treino B - Costas e Bíceps):\n"
        "• Barra fixa (ou puxada na frente): 4 sets de 8-12 repetições\n"
        "• Remada curvada com barra: 4 sets de 8-12 repetições\n"
        "• Puxada na polia alta (pegada aberta): 3 sets de 10-15 repetições\n"
        "• Rosca direta com barra reta: 3 sets de 10-12 repetições\n"
        "• Rosca martelo: 3 sets de 10-12 repetições\n\n"
        "Quinta-feira (Treino C - Pernas e Ombros):\n"
        "• Agachamento livre: 4 sets de 8-12 repetições\n"
        "• Leg press: 4 sets de 10-15 repetições\n"
        "• Extensão de pernas: 3 sets de 10-12 repetições\n"
        "• Elevação lateral: 4 sets de 10-15 repetições\n"
        "• Desenvolvimento militar: 4 sets de 8-12 repetições\n"
        "• Elevação frontal com halteres: 3 sets de 10-12 repetições\n\n"
        "Sexta-feira (Treino D - Abdômen e Panturrilhas):\n"
        "• Prancha: 3 sets de 30-60 segundos\n"
        "• Crunches: 3 sets de 15-20 repetições\n"
        "• Elevação de pernas suspenso (na barra fixa): 3 sets de 10-15 repetições\n"
        "• Flexão plantar sentado: 4 sets de 10-15 repetições\n"
        "• Gêmeos em pé: 4 sets de 10-15 repetições\n");
    
   }
  else if ((sexo == 'm' || sexo == 'M') && (obj == 2) && (disponibilidade == 5)){

    printf("Segunda-feira (Treino A - Peito e Tríceps):\n"
       "• Supino reto: 4 sets de 8-12 repetições\n"
       "• Supino inclinado com halteres: 4 sets de 8-12 repetições\n"
       "• Crucifixo inclinado: 3 sets de 10-15 repetições\n"
       "• Paralelas: 3 sets até a falha muscular\n"
       "• Extensão de tríceps com corda (na polia alta): 3 sets de 10-12 repetições\n"
       "• Tríceps francês (deitado): 3 sets de 10-12 repetições\n\n"
       "Terça-feira (Treino B - Costas e Bíceps):\n"
       "• Barra fixa (ou puxada na frente): 4 sets de 8-12 repetições\n"
       "• Remada curvada com barra: 4 sets de 8-12 repetições\n"
       "• Puxada na polia alta (pegada aberta): 3 sets de 10-15 repetições\n"
       "• Rosca direta com barra reta: 3 sets de 10-12 repetições\n"
       "• Rosca martelo: 3 sets de 10-12 repetições\n\n"
       "Quarta-feira (Treino C - Pernas e Ombros):\n"
       "• Agachamento livre: 4 sets de 8-12 repetições\n"
       "• Leg press: 4 sets de 10-15 repetições\n"
       "• Extensão de pernas: 3 sets de 10-12 repetições\n"
       "• Elevação lateral: 4 sets de 10-15 repetições\n"
       "• Desenvolvimento militar: 4 sets de 8-12 repetições\n"
       "• Elevação frontal com halteres: 3 sets de 10-12 repetições\n\n"
       "Quinta-feira (Treino D - Abdômen e Lombar):\n"
       "• Prancha: 3 sets de 30-60 segundos\n"
       "• Crunches: 3 sets de 15-20 repetições\n"
       "• Elevação de pernas suspenso (na barra fixa): 3 sets de 10-15 repetições\n"
       "• Hiperextensão lombar: 3 sets de 10-12 repetições\n\n"
       "Sexta-feira (Treino E - Panturrilhas e Cardio):\n"
       "• Flexão plantar sentado: 4 sets de 10-15 repetições\n"
       "• Gêmeos em pé: 4 sets de 10-15 repetições\n"
       "• Cardio: 20-30 minutos de corrida, ciclismo, pular corda, ou outra atividade cardiovascular de sua escolha.\n");
    }
  else{
    printf("Número inválido");
    return 0;
  }
   printf("Os treinos com uma dieta balanceada, potêncializa os resultados, gostaria\nde algumas sugestões?\n1- SIM\n2- NÃO\n");
    scanf("%d", &sug);

    if(sug == 1){
      printf("Qual das dietas mais te agrada?\n1- Déficit calórico\n2- Superávit calórico\n");
      scanf("%d", &dieta);
    }
    else{
        printf("AGRADECEMOS PELO ACESSO E CONTINUE FOCADO NOS SEUS OBJETIVOS!!!");
      }
    if(dieta == 1){
      printf(" Para perder peso de forma saudável, é necessário um déficit calórico, que é consumir uma quantidade inferior de calorias ao que o corpo gasta. Um déficit saudável, é em torno de 500 a 750 calorias por dia, o que resulta em uma perca de 500g a 1kg por semana.\n Embora seja importante criar um déficit calórico para perder peso, é igualmente crucial garantir que sua dieta seja composta por alimentos nutritivos e equilibrados. Certifique-se de incluir uma variedade de alimentos ricos em nutrientes, como proteínas magras, carboidratos complexos, gorduras saudáveis, frutas e vegetais.\n AGRADECEMOS PELO ACESSO E CONTINUE FOCADO NOS SEUS OBJETIVOS!!!");
  }
    else if(dieta == 2){
      printf(" Para obter um ganho saudável de massa, é necessário um superávit calórico, que é consumir mais calorias do que o corpo gasta. Um superávit satisfatório e saudável gira em torno de 250 a 500 calorias extras por dia.\n É essencial garantir que essas calorias extras sejam provenientes de fontes nutricionalmente densas e equilibradas. Uma proporção adequada de macronutrientes, carboidratos, proteínas e de gorduras saudáveis.\n AGRADECEMOS PELO ACESSO E CONTINUE FOCADO NOS SEUS OBJETIVOS!!!");
    }
  }