#include <stdio.h>
#include <string.h> 
int main(void) {
  char opcao;
  char user[100], senha[100], testeU[100], testeS[100];
  
  do {
  printf("Bem-vindo!\n a)Fazer cadastro \n b)Entrar\n c)Sair\n");
  scanf(" %c", &opcao);
    if (opcao == 'a' || opcao == 'A') {
      printf("Nome de usúario: ");
      scanf("%s", user);
      printf("Senha: ");
      scanf("%s", senha);
      printf("\n");
      printf("*****************************\n");
      printf("Cadastro realizado com sucesso!\n");
      printf("*****************************\n");
    }
  if (opcao == 'b' || opcao == 'B') {
    printf("Nome de usúario: ");
    scanf("%s", testeU);
    printf("Senha: ");
    scanf("%s", testeS);
    printf("\n");
    if (strcmp(testeU, user) == 0 && strcmp(testeS, senha) == 0) {
      printf("******************************************\n");
      printf("Bem-vindo, %s", user);
      break;
    } else{
      printf("Nome de usúario ou senha incorretos, voltando ao menu...\n");
      printf("*****************************************\n");
      printf("\n");
      }
    }
  }while (opcao != 'c' && opcao != 'C');
}